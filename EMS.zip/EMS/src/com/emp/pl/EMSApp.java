package com.emp.pl;

import java.util.Scanner;

import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;
import com.emp.service.EmployeeService;
import com.emp.service.EmployeeServiceImpl;


public class EMSApp {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num=0;
		while(num<5){
		System.out.println("\n---------------------"
				+ "\n1.Add Employee\n2.Delete Employee\n3.View Employee\n4.View Employee By Id\n5.Exit\n---------------------"
				+ "\nEnter your choice: ");
		num=sc.nextInt();
		
		int id=0;
		EmployeeBean bean=new EmployeeBean();
		EmployeeService service=new EmployeeServiceImpl();
		EmployeeServiceImpl serviceImpl=new EmployeeServiceImpl();
		
		switch(num)
		
		{
			case 1:	System.out.println("Enter employee name: ");
					String name=sc.next();
					if (serviceImpl.isValidName(name)) {
						bean.setEmployeeName(name);
					}
					else{
						System.out.println("Invalid name prototype");
					}
					System.out.println("Enter employee Salary: ");
					int salary=sc.nextInt();
					if (serviceImpl.isValidSalary(salary)) {
						bean.setEmployeeSalary(salary);
					}
					else{
						System.out.println("Invalid salary");
					}
					
					try {
						service.addEmployee(bean);
					} catch (EmployeeException e) {
						System.out.println("Unable to insert");
					}
					break;
			case 2:	System.out.println("Enter employee id: ");
					id=sc.nextInt();
					try {
						service.deleteEmployeeByID(id);
					} catch (EmployeeException e) {
					System.out.println("Unable to delete");
					}
					break;
			case 3: try {
						service.viewAllEmployee();
					} catch (EmployeeException e) {
						System.out.println("Unable to view");
					}
					break;
			case 4: System.out.println("Enter employee id: ");
					id=sc.nextInt();
					try {
						service.viewEmployeeByID(id);
					} catch (EmployeeException e) {
						System.out.println("No such ID exists");	}
					break;
			case 5: System.exit(0);
					break;
			
			default:System.out.println("Invalid choice");
		}
		}	
		sc.close();
		
	}

}
