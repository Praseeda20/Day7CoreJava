package com.emp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;
import com.emp.util.DBConnection;

public class EmployeeDaoImpl implements EmployeeDao{
	int id;
	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		Connection con=null;
		int id=0;
		String cmd="Insert into emp_tbl (empid, empname, empsalary) "
				+ "values(?,?,?)";
		try {
			con=DBConnection.getConnection();
			id=generateEmployeeId();
			PreparedStatement pstmt = con.prepareStatement(cmd);

			pstmt.setInt(1, id);
			pstmt.setString(2, bean.getEmployeeName());
			pstmt.setInt(3, bean.getEmployeeSalary());
			pstmt.executeUpdate();
			System.out.println("Employee added"+id);
		} 
		catch (SQLException e) {
			throw new EmployeeException("Unable to insert");
		}
		return id;
	}

	private int generateEmployeeId() {
		int id=0;
		Connection con=null;
		String qry="Select empid_sequence.nextval from dual";
		try {
			con=DBConnection.getConnection();
			Statement stmt=con.createStatement();
			ResultSet rst=stmt.executeQuery(qry);
			rst.next();
			id=rst.getInt(1);
		} catch (SQLException | EmployeeException e) {
			e.printStackTrace();
		}
		return id;
	}
	
	@Override
	public EmployeeBean deleteEmployeeByID(int id) throws EmployeeException {
		EmployeeBean emp=new EmployeeBean();
		Connection con=null;
		String qry="delete from emp_tbl where empid=(?)";
		try {
			con=DBConnection.getConnection();
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setInt(1, id);
			pstmt.executeUpdate();
			System.out.println("employee deleted "+id);
		} catch (SQLException e) {
			throw new EmployeeException("Unable to delete");
		}
		return emp;
	}

	@Override
	public List<EmployeeBean> viewAllEmployee() throws EmployeeException {
		List<EmployeeBean> list=new ArrayList<EmployeeBean>();
		Connection con=null;
		try {
			con=DBConnection.getConnection();
			Statement stmt = con.createStatement();
			String qry="select empid, empname, empsalary from emp_tbl";
			ResultSet rst= stmt.executeQuery(qry);
			while(rst.next())
			{
				EmployeeBean bean=new EmployeeBean();
				bean.setEmpId(rst.getInt("empid"));
				bean.setEmployeeName(rst.getString("empname"));
				bean.setEmployeeSalary(rst.getInt("empsalary"));
				list.add(bean);
			}
			list.forEach(p->System.out.println(p));
			
		} catch (SQLException e) {
			System.out.println("Unable to view");
		}
		
		return list;
	}

	@Override
	public EmployeeBean viewEmployeeByID(int empid) throws EmployeeException {
		EmployeeBean emp=new EmployeeBean();
		try {
			Connection con=null;
			String qry="select empid, empname, empsalary from emp_tbl where empid=(?)";
				con=DBConnection.getConnection();
				PreparedStatement pstmt = con.prepareStatement(qry);
				pstmt.setInt(1, id);
				ResultSet rst=pstmt.executeQuery();
				while(rst.next()){
					emp.setEmpId((rst.getInt(1)));
					emp.setEmployeeName(rst.getString(2));
					emp.setEmployeeSalary(rst.getInt(3));
	                
	            }
				System.out.println("Employee: "+id);
		        System.out.println(emp);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return emp;
	}


}
