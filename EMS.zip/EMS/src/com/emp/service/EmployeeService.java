package com.emp.service;

import java.util.List;

import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;

public interface EmployeeService {
	public int addEmployee(EmployeeBean bean)throws EmployeeException;
	public List<EmployeeBean> viewAllEmployee()throws EmployeeException;
	EmployeeBean deleteEmployeeByID(int id) throws EmployeeException;
	EmployeeBean viewEmployeeByID(int id) throws EmployeeException;
	//public boolean isValidName(String name);
}
