package com.emp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.emp.bean.EmployeeBean;
import com.emp.dao.EmployeeDao;
import com.emp.dao.EmployeeDaoImpl;
import com.emp.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService {
	private EmployeeDao employeeDao = new EmployeeDaoImpl();

	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		int id = employeeDao.addEmployee(bean);
		return id;
	}

	@Override
	public EmployeeBean deleteEmployeeByID(int id) throws EmployeeException {
		EmployeeBean emp = employeeDao.deleteEmployeeByID(id) ;
		return emp;
	}

	@Override
	public List<EmployeeBean> viewAllEmployee() throws EmployeeException {
		List<EmployeeBean>  emp = employeeDao.viewAllEmployee() ;
		return null;
	}

	@Override
	public EmployeeBean viewEmployeeByID(int empid) throws EmployeeException {
		EmployeeBean  emp = employeeDao.viewEmployeeByID(empid) ;
		return null;
	}

	public boolean isValidName(String empName){
		Pattern namePattern=Pattern.compile("^[A-Z]{1}[a-z]{2,}$");
		Matcher nameMatcher=namePattern.matcher(empName);
		return nameMatcher.matches();
	}
	public boolean isValidSalary(int empSalary){
		Pattern salPattern=Pattern.compile("^[1-90-9]{3,}$");
		Matcher salMatcher=salPattern.matcher(String.valueOf(empSalary));
		return salMatcher.matches();
	}
	

}
