package com.emp.bean;

public class EmployeeBean {

	private int empId;
	@Override
	public String toString() {
		return "EmployeeBean [empId=" + empId + ", employeeName="
				+ employeeName + ", employeeSalary=" + employeeSalary + "]";
	}
	public synchronized int getEmpId() {
		return empId;
	}
	public synchronized void setEmpId(int empId) {
		this.empId = empId;
	}
	private String employeeName;
	private int employeeSalary;
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public int getEmployeeSalary() {
		return employeeSalary;
	}
	public void setEmployeeSalary(int employeeSalary) {
		this.employeeSalary = employeeSalary;
	}
	
	

}
